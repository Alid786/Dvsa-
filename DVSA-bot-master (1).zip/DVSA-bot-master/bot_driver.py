import undetected_chromedriver as uc

WINDOW_SIZE = "1920,1080"


class BotDriver:
    def __init__(self, head_less=True):
        self._setup_options(head_less)

    def _setup_options(self, head_less):
        self.chrome_options = uc.ChromeOptions()
        self.chrome_options.add_argument("--no-sandbox")
        self.chrome_options.add_argument("--window-size=%s" % WINDOW_SIZE)
        self.chrome_options.add_argument(
            "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/92.0.4515.131 "
            "Safari/537.36")
        self.chrome_options.headless = head_less

    def get_driver(self):
        return uc.Chrome(
            chrome_options=self.chrome_options
        )
