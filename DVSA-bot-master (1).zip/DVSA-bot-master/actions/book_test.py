import time

from actions.action import Action
from bot_driver import BotDriver
from utils import Utils


class BookTest(Action):
    def __init__(self, browser=None):
        self.browser = browser or BotDriver().get_driver()
        self.utils = Utils(self.browser)

    def perform(self):
        time.sleep(100)
