import logging
import os
import time

from dotenv import load_dotenv
from selenium.webdriver.common.by import By

from actions.action import Action
from bot_driver import BotDriver
from captcha_solver import CaptchaSolver
from utils import Utils

load_dotenv()

logger = logging.getLogger()


class Login(Action):
    def __init__(self, browser=None):
        self.browser = browser or BotDriver().get_driver()
        self.utils = Utils(self.browser)
        self.captcha_solver = CaptchaSolver(
            browser=self.browser,
            anti_captcha_api_key=os.environ["ANTI_CAPTCHA_API_KEY"]
        )
        self._set_credentials()

    def _set_credentials(self):
        self.username = os.environ["USERNAME"]
        self.password = os.environ["PASSWORD"]

    def _open_login_page(self):
        self.browser.get('https://www.gov.uk/book-pupil-driving-test/')
        self.utils.cooldown()
        self._click_get_started()

    def _click_get_started(self):
        xpath = "//*[@id='get-started']/a"
        self.utils.wait_for_element_visibility(xpath, 120)
        self.utils.cooldown()
        self.browser.find_element(by=By.XPATH, value=xpath).click()
        self.utils.cooldown()

    def _wait_for_captcha(self):
        self.browser.switch_to.frame(
            frame_reference=self.browser.find_element(by=By.XPATH, value='//*[@id="main-iframe"]'))
        captcha_verify_button = '//*[@id="captcha-box"]/div[2]/div[2]/div[1]/div[3]'
        self.utils.wait_for_element_visibility(captcha_verify_button, 120)

    def _login(self):
        self.utils.cooldown(5)

        self.utils.wait_for_element_visibility('//*[@id="user_id"]', 120)
        self.utils.send_keys_slow(self.username, self.browser.find_element(by=By.ID, value='user_id'))
        self.utils.cooldown()
        self.utils.send_keys_slow(self.password, self.browser.find_element(by=By.ID, value='password'))
        self.utils.cooldown()
        self.browser.find_element(by=By.ID, value='continue').click()
        time.sleep(5)
        if 'Enter the access code' in self.browser.page_source:
            logger.info('Credential requires 6 digit code')
            time.sleep(100)

    def _is_captcha_required(self):
        time.sleep(5)
        return "Request unsuccessful. Incapsula incident ID:" in self.browser.page_source

    def perform(self):
        self._open_login_page()
        self.utils.cooldown()
        if self._is_captcha_required():
            self._wait_for_captcha()
            self.captcha_solver.solve_captcha()
            self.perform()
        else:
            self._login()
