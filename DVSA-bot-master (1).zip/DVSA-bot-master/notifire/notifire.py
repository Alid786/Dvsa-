from abc import ABC, abstractmethod


class Notifire(ABC):
    @abstractmethod
    def notify(self, booking_info):
        pass
