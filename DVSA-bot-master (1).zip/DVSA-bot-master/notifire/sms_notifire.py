from notifire.notifire import Notifire


class SMSNotifire(Notifire):
    def notify(self, booking_info):
        pass

