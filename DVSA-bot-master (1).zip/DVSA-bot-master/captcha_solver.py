import json
import logging
import re

from anticaptchaofficial.geetestproxyless import geetestProxyless

logger = logging.getLogger()


class CaptchaSolver:

    def __init__(self, browser, anti_captcha_api_key):
        self.browser = browser
        self.anti_captcha_api_key = anti_captcha_api_key

    def _set_solution_validator_url(self):
        # Define the regular expression to match the URL
        pattern = r'"/_Incapsula_Resource\?SWCGHOEL=[^"]+"'
        match = re.search(pattern, self.browser.page_source)
        if match:
            path = match.group(0).strip('"')
            url = f"https://driver-services.dvsa.gov.uk{path}"
            logger.info(f"solution_validator_url: {url}")
            self.solution_validator_url = url

    def _set_problem_url(self):
        # Define the regular expression to match the URL
        pattern = r'"/_Incapsula_Resource\?SWCNGEEC=[^"]+"'
        match = re.search(pattern, self.browser.page_source)
        if match:
            path = match.group(0).strip('"')
            url = f"https://driver-services.dvsa.gov.uk{path}"
            logger.info(f"problem_url: {url}")
            self.problem_url = url

    def _get_new_problem(self):
        self.browser.get(self.problem_url)
        captcha_problem = json.loads(re.sub(r'<.*?>', '', self.browser.page_source))
        logger.info(captcha_problem)
        return captcha_problem

    def _solve_captcha_with_anti_captcha(self, captcha_problem):
        solver = geetestProxyless()
        solver.set_verbose(1)
        solver.set_key(self.anti_captcha_api_key)
        solver.set_website_url("https://driver-services.dvsa.gov.uk")
        solver.set_gt_key(captcha_problem["gt"])
        solver.set_challenge_key(captcha_problem["challenge"])
        return solver.solve_and_return_solution()

    def _set_cookie(self, captcha_solution):
        # Prepare the JavaScript code to make the POST request
        body = f"geetest_challenge={captcha_solution['challenge']}&" \
               f"geetest_validate={captcha_solution['validate']}&geetest_seccode={captcha_solution['seccode']}"
        js_code = f"""
            fetch("{self.solution_validator_url}", 
            {{
                method: "POST",
                headers: {{
                    "content-type": "application/x-www-form-urlencoded"
                }},
                body: "{body}"
            }});
            """

        # Execute the JavaScript code
        self.browser.execute_script(js_code)

        # Wait for a moment to allow the request to be sent and processed
        self.browser.implicitly_wait(5)  # Adjust the wait time as needed

    def solve_captcha(self):
        self._set_problem_url()
        self._set_solution_validator_url()
        problem = self._get_new_problem()
        solution = self._solve_captcha_with_anti_captcha(problem)
        self._set_cookie(solution)
