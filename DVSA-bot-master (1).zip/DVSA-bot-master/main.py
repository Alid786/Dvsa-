import logging

from actions.book_test import BookTest
from actions.login import Login
from bot_driver import BotDriver

logger = logging.getLogger()

logging.basicConfig(level=logging.INFO)


class BotRunner:
    def __init__(self):
        self.driver = BotDriver(head_less=False).get_driver()
        self.login = Login(browser=self.driver)
        self.book_test = BookTest(browser=self.driver)

    def run(self):
        # self.login.perform()
        self.driver.get("file:///Users/anonymous/Downloads/DVSA%20home%20-%20Business%20service%20for%20drive2pass.html")
        self.book_test.perform()


if __name__ == "__main__":
    BotRunner().run()
