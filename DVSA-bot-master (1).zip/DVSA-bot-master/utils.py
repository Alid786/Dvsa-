import logging
import random

from anticaptchaofficial.geetestproxyless import *
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait

logger = logging.getLogger()


class Utils:

    def __init__(self, browser):
        self.browser = browser

    def wait_for_element_visibility(self, xpath: str, timeout: int = 20):
        WebDriverWait(self.browser, timeout).until(EC.visibility_of_element_located((By.XPATH, xpath)))

    @staticmethod
    def cooldown(max_time: float = 1.0):
        time.sleep(random.uniform(max_time / 4, max_time))

    @staticmethod
    def send_keys_slow(keys: str, element):
        for key in keys:
            element.send_keys(key)
            time.sleep(random.uniform(0.05, 0.1))

    def scroll_to_view(self, element, offset=200):
        self.browser.execute_script(
            """
            //arguments[0].scrollIntoView(true);
            var bodyRect = document.body.getBoundingClientRect(),
            elemRect = arguments[0].getBoundingClientRect(),
            offset   = elemRect.top - bodyRect.top - arguments[1];
            window.scrollTo(0, offset);
            """, element, offset)

    def scroll_to_top_of_page(self):
        self.browser.execute_script("window.scrollTo(0, 0);")
